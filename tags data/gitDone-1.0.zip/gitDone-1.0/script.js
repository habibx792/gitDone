<<<<<<< Updated upstream
<<<<<<< Updated upstream
console.log("Hello i am working with git  \n and i am doint well");
let i=1000;
while(i>=0)
{
	console.log("i love the coding");
	console.log(i+100);
         i--;
}
=======
console.log("Hello i am working with git  \n and i am doint well");
>>>>>>> Stashed changes
=======
console.log("Hello i am working with git  \n and i am doint well");
>>>>>>> Stashed changes
